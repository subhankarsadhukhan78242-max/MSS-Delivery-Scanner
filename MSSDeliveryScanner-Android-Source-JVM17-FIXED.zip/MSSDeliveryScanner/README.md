# MSS Delivery Scanner

Android helper for My Supermarket Simulator 3D. It uses Android MediaProjection to capture the screen and bundled Google ML Kit OCR to read visible `M:SS` delivery timers. It sums the detected timers and shows the result in a small overlay.

## Use
1. Open the game and open the **Deliveries** panel.
2. Install/build this app.
3. Allow **Display over other apps**.
4. Tap **Start live scanning**.
5. Approve Android's screen-capture prompt.
6. Keep the Deliveries panel visible; the overlay updates about every 1.2 seconds.

The current implementation intentionally scans the central area where the Deliveries dialog appears to reduce false detections from the game's clock and event timers.

## Notes
- Android will show a persistent screen-capture/foreground-service indicator while scanning.
- Screen text is processed on-device by ML Kit; this project does not upload screenshots.
- If the game changes its UI layout, the crop can be adjusted in `CaptureService.kt`.
