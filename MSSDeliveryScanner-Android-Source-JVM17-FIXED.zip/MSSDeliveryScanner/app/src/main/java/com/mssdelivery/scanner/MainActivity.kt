package com.mssdelivery.scanner

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val captureCode = 7001
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.start).setOnClickListener { startScanner() }
        findViewById<Button>(R.id.stop).setOnClickListener { stopScanner() }
        updateStatus()
    }

    private fun startScanner() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Allow 'Display over other apps', then tap Start again."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), captureCode)
    }

    @Deprecated("Activity result API kept simple for this standalone sample")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != captureCode || resultCode != Activity.RESULT_OK || data == null) {
            status.text = "Screen capture permission was not granted."
            return
        }
        val service = Intent(this, CaptureService::class.java).apply {
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_DATA, data)
        }
        startForegroundService(service)
        status.text = "Scanning the Deliveries panel…"
    }

    private fun stopScanner() {
        stopService(Intent(this, CaptureService::class.java))
        stopService(Intent(this, OverlayService::class.java))
        status.text = "Scanner stopped."
    }

    private fun updateStatus() { status.text = "Ready. Open the Deliveries panel in the game, then tap Start." }
}
