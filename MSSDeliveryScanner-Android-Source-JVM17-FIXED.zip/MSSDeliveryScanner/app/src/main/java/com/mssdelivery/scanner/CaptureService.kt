package com.mssdelivery.scanner

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.regex.Pattern

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var busy = false
    private var lastScan = 0L
    private val timerPattern = Pattern.compile("(?<!\\d)(\\d{1,2})\\s*[:.]\\s*(\\d{2})(?!\\d)")

    // Last OCR reading of remaining-seconds per delivery, plus when it was captured.
    // Kept so the overlay can keep counting down after the Deliveries panel is closed
    // instead of resetting the moment OCR stops seeing the timers on screen.
    @Volatile private var trackedSeconds: List<Long> = emptyList()
    @Volatile private var trackedAtElapsed: Long = 0L
    private val tickIntervalMs = 1000L
    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, tickIntervalMs)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        thread = HandlerThread("MSS-OCR").also { it.start() }
        handler = Handler(thread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) { intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java) } else { @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA) }
        if (code == Activity.RESULT_OK && data != null && projection == null) startCapture(code, data)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        startForeground(1001, notification(), if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0)
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r -> handleFrame(r) }, handler)
        virtualDisplay = projection!!.createVirtualDisplay("MSSDeliveryScanner", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        startService(Intent(this, OverlayService::class.java))
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun handleFrame(r: ImageReader) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastScan < 1200 || busy) { r.acquireLatestImage()?.close(); return }
        val image = r.acquireLatestImage() ?: return
        lastScan = now
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val paddedWidth = image.width + rowPadding / pixelStride
            val full = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            buffer.rewind(); full.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(full, 0, (image.height * 0.12f).toInt().coerceAtLeast(0), image.width, (image.height * 0.83f).toInt().coerceAtMost(image.height - (image.height * 0.12f).toInt()))
            full.recycle()
            busy = true
            recognize(cropped)
        } catch (_: Exception) { busy = false } finally { image.close() }
    }

    private fun recognize(bitmap: Bitmap) {
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val found = mutableListOf<Pair<Int, Int>>()
                for (block in result.textBlocks) for (line in block.lines) {
                    val box = line.boundingBox ?: continue
                    val raw = line.text.uppercase(Locale.US).replace('O','0').replace('I','1').replace('L','1')
                    val m = timerPattern.matcher(raw)
                    while (m.find()) {
                        val min = m.group(1)?.toIntOrNull() ?: continue
                        val sec = m.group(2)?.toIntOrNull() ?: continue
                        if (min <= 59 && sec < 60 && box.left > bitmap.width * 0.20 && box.right < bitmap.width * 0.85) found.add(min to sec)
                    }
                }
                // De-duplicate repeated OCR hits while keeping the visible queue order.
                val unique = found.distinct().take(10)
                // Only overwrite the tracked snapshot when the panel actually shows timers.
                // If the panel is closed and OCR finds nothing, keep counting down the last
                // reading instead of wiping it out.
                if (unique.isNotEmpty()) {
                    trackedSeconds = unique.map { it.first * 60L + it.second }
                    trackedAtElapsed = SystemClock.elapsedRealtime()
                }
                bitmap.recycle()
            }
            .addOnFailureListener { bitmap.recycle() }
            .addOnCompleteListener { busy = false }
    }

    // Runs once a second regardless of whether OCR is currently seeing the Deliveries panel,
    // so the overlay keeps counting down live using the last known snapshot.
    private fun tick() {
        val snapshot = trackedSeconds
        if (snapshot.isEmpty()) { updateOverlay(0, 0L); return }
        val elapsedSec = (SystemClock.elapsedRealtime() - trackedAtElapsed) / 1000L
        val remaining = snapshot.map { it - elapsedSec }.filter { it > 0 }
        if (remaining.size != snapshot.size) {
            // Some deliveries have counted down to zero since the last reading; drop them
            // so they don't keep contributing to the total.
            trackedSeconds = remaining
            trackedAtElapsed = SystemClock.elapsedRealtime()
        }
        updateOverlay(remaining.size, remaining.sum())
    }

    private fun updateOverlay(count: Int, total: Long) {
        val finish = if (count > 0) "Queue total" else ""
        val i = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_UPDATE).apply {
            putExtra("count", count); putExtra("total", total); putExtra("finish", finish)
        }
        startService(i)
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("MSS Delivery Scanner")
            .setContentText("Live screen scanning is active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).setContentIntent(open).build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL, "Screen scanner", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        runCatching { virtualDisplay?.release() }; virtualDisplay = null
        runCatching { reader?.close() }; reader = null
        runCatching { projection?.stop() }; projection = null
        runCatching { recognizer.close() }
        stopService(Intent(this, OverlayService::class.java))
        if (::thread.isInitialized) thread.quitSafely()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object { const val EXTRA_RESULT_CODE = "result_code"; const val EXTRA_DATA = "projection_data"; private const val CHANNEL = "scanner" }
}
