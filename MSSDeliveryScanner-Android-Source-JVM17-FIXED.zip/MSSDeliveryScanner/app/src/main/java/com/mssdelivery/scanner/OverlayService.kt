package com.mssdelivery.scanner

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var view: TextView? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "🚚  Delivery scanner\nOpen Deliveries"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(18, 12, 18, 12)
            setBackgroundColor(Color.argb(225, 20, 25, 35))
            elevation = 12f
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(WRAP, WRAP, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 70
        }
        wm.addView(tv, lp)
        view = tv
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_UPDATE) {
            val count = intent.getIntExtra("count", 0)
            val total = intent.getLongExtra("total", 0)
            val finish = intent.getStringExtra("finish") ?: ""
            view?.text = if (count > 0) "🚚  $count deliveries\n⏱  ${format(total)}\n$finish" else "🚚  No delivery timers detected\nOpen the Deliveries panel"
        }
        return START_STICKY
    }

    private fun format(s: Long): String {
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) "%dh %02dm %02ds".format(h, m, sec) else "%dm %02ds".format(m, sec)
    }

    override fun onDestroy() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    companion object { const val ACTION_UPDATE = "com.mssdelivery.scanner.UPDATE"; private const val WRAP = -2 }
}
